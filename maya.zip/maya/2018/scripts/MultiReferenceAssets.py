import maya.cmds as cm
import os

assetsPath = "H:\\ShawnVFX\\Projects\\FlameForce_909\\02_Assets\\Vehicles"

assetDirs = os.listdir(assetsPath)

for eachDir in assetDirs:
    eachGeoDir = assetsPath + "\\" + eachDir + "\\Geo"
    geoDirContents = os.listdir(eachGeoDir)
    
    for eachFile in geoDirContents:
        if "proxyRig" in eachFile:
            eachFilePath = eachGeoDir + "\\" + eachFile
            eachFileName = eachFile.split("_proxyRig")[0]
            cm.file(eachFilePath,reference=True,namespace=eachFileName)