import maya.cmds as cm

sel = cm.ls(sl=True)

source = sel[0]

for i in range(1,len(sel)):
    obj = sel[i]
    
    objDup = cm.duplicate(source)
    pCNode = cm.parentConstraint(obj,objDup,maintainOffset=False)
    cm.delete(pCNode)
    #pos = cm.xform(obj,q=True,ws=True,t=True)
    #rot = cm.xform(obj,q=True,ws=True,r=True)
    scal = cm.xform(obj,scale=True,q=True)
    
    cm.xform(objDup,scale=scal)
    
    
    
    #cm.xform(objInstance,t=pos,ws=True)
    #cm.xform(objInstance,ro=rot,ws=True)
    
#cm.delete(source)