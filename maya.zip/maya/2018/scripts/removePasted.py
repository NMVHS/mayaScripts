import maya.cmds as cm
import string

def main():
    sel = cm.ls(sl=True,shortNames=True)
    
    for each in sel:
        shortName = newName = each.split("|")[-1]
        if shortName.startswith("pasted__"):
            newName = string.replace(newName,"pasted__","")
            print newName
            cm.rename(each,newName)
        

if __name__ == "__main__":
    main()