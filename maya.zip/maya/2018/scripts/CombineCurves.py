#
# Copyright (C) by Adrian Sochacki, 2018. All rights reserved.
#
# Description: Combines several curves into a single one
# How to use: Just select at least 2 nurbsCurves and run the script
#
# Tested in Maya 2016, 2017, 2018
#
# Version: 1.0.3
#

import maya.cmds as cmds
import sys

#Combine your curves into one new curve:
def combineCRV():
	sel = cmds.ls(sl = True)
	if len(sel) <= 1:
		sys.exit("Please select first at least 2 curves you want to combine.\n")

	selType = cmds.filterExpand(selectionMask = 9)
	if selType == None:
		sys.exit("Please select first an object of type 'nurbsCurve.\n'")
	else:
		shape = cmds.listRelatives(shapes = True)
		for x in range(len(sel)):
			cmds.makeIdentity(sel[x], apply = True, rotate = True, scale = True, translate = True)

		group = cmds.group(empty = True, name = "newCurve_CRV")

		cmds.select(shape[0])
		for x in range(1, (len(shape))):
			cmds.select(shape[x], add  = True)
		cmds.select(group, add = True) 
		cmds.parent(relative = True, shape = True)
		cmds.delete(sel)
		sys.stdout.write("New curve created.\n")

if __name__ == '__main__':
	combineCRV()