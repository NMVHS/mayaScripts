import maya.cmds as cm

#grab all the selected objects

selectedObjects = cm.ls(sl=True)

#save first one into variable

#pop first one out of the selected objects list

driver = selectedObjects.pop(0)

#for each object in the selected objects list

for object in selectedObjects:

    cm.select([driver,object])

    #transfer attributes

    cm.transferAttributes(sampleSpace=4,transferUVs=2, transferColors=2 )