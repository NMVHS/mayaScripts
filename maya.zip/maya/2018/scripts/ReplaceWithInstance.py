import maya.cmds as cm

sel = cm.ls(sl=True)

source = sel[0]

for i in range(1,len(sel)):
    obj = sel[i]
    
    objInstance = cm.instance(source)
    cm.parentConstraint(obj,objInstance,maintainOffset=False)
    #pos = cm.xform(obj,q=True,ws=True,t=True)
    #rot = cm.xform(obj,q=True,ws=True,r=True)
    scal = cm.xform(obj,scale=True,q=True)
    
    cm.xform(objInstance,scale=scal)
    
    
    #cm.xform(objInstance,t=pos,ws=True)
    #cm.xform(objInstance,ro=rot,ws=True)
    cm.delete(obj)
    
#cm.delete(source)