import maya.cmds as cm
import maya.mel as mel
import os

assetsDirPath = "G:\\ShawnRoot\\Projects\\FlameForce_909\\02_Assets\\Architectures"

assetDirs = os.listdir(assetsDirPath)

cnt = 0
for eachDir in assetDirs:
    cnt += 1
    #if cnt >3: continue
    
    geoDirPath = assetsDirPath + "\\" + eachDir + "\\" + "Geo"
    mayaFilePath = geoDirPath + "\\" + os.listdir(geoDirPath)[0]
    mayaScenePrefix = mayaFilePath.split("\\")[-1].split("v001")[0]
    
    cm.file(mayaFilePath,open=True,prompt=False,force=True)
    
    cm.setAttr("perspShape.nearClipPlane", 10)
    cm.setAttr("perspShape.farClipPlane", 1000000)
    
    
    dayObj = mayaScenePrefix + "Day"
    nightObj = mayaScenePrefix + "Night"
    
    cm.xform(nightObj,t=[0,0,0],ws=True)
    cm.hide(dayObj)
    cm.select(clear=True)
    cm.select(nightObj)
    
    projectPath = cm.workspace(q=True,rootDirectory=True)
    sceneName = cm.file(q=True,sceneName=True,shortName=True)
    sceneName = os.path.splitext(sceneName)[0]

    #----generate the filename-------------
    selections = cm.ls(sl=True)
    rsProxyName = sceneName + ".####.rs"

    #----figure out the correct path-----------
    savingDir = projectPath + "RsProxy/" +  sceneName
    if not os.path.isdir(savingDir):
        os.makedirs(savingDir)

    savingPath = savingDir + "/" + rsProxyName
    #----export-------------------------
    #check options
    exportCmd = 'rsProxy -fp '  + '"' + savingPath + '"' + " -sl -z"

    exportCmd += " -s 101"
    exportCmd += " -e 101"
    exportCmd += " -b 1"

    print exportCmd
    mel.eval(exportCmd)
    
    cm.file(save=True)
    
    
    
    
    
    
    
    

    
    

