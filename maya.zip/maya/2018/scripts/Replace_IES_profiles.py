import maya.cmds as cm

sel = cm.ls(sl=True)

for each in sel:
    cm.setAttr(each + ".profile","G:/ShawnRoot/Resources/CG/IES/IES2/36.ies",type="string")