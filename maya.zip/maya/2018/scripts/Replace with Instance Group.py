import maya.cmds as cm

selection = cm.ls(sl = True)

sourceObj = selection[0]
selection.pop(0)


sourceAll = cm.listRelatives(sourceObj, children = True)
sourceShape = []
for eachSource in sourceAll:
    sourceShape.append(cm.listRelatives(eachSource)[0])

print sourceShape

cnt = 0
for eachObj in selection:
    children = cm.listRelatives(eachObj, children = True)
    for eachMesh in children:
        meshShape = cm.listRelatives(eachMesh)
        cm.parent(sourceShape[cnt],eachMesh,add=True,shape=True)
        
        cm.delete(meshShape)
        cnt = cnt + 1
        
    
        