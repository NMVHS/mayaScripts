import maya.cmds as cm

sel = cm.ls(sl=True)

for each in sel:
    assetName = each.split("_v")[0]
    toReplaceObj = assetName + ":" + assetName
    
    instancedObj = cm.instance(toReplaceObj)
    
    instanceNewName = toReplaceObj
    cnt = 1
    while cm.objExists(instanceNewName):
        instanceNewName = toReplaceObj + "_" + str(cnt).zfill(2)
        cnt += 1
    
    
    instancedObj = cm.rename(instancedObj,instanceNewName)
    
    children = cm.listRelatives(each,children=True,shapes=False)
    
    for eachChild in children:
        if "Shape" not in eachChild:
            cm.delete(eachChild)
    
    cm.parent(instancedObj,each)
    cm.xform(instancedObj,t=[0,0,0])
    cm.xform(instancedObj,ro=[0,0,0])