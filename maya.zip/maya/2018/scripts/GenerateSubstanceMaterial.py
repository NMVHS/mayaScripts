#select the meterial,rs normal map node and 4 maps (diffuse, roughness, metallic, normal) to generate a substance material

import maya.cmds as cm

sel = cm.ls(sl=True)

for each in sel:
    selType = cm.objectType(each)
    
    if selType == "RedshiftMaterial":
        rsMat = each
    else:
        if "Normal" in each:
            normalMap = each
        elif "Roughness" in each:
            roughMap = each
        elif "Metallic" in each:
            metalMap = each
        elif "Diffuse" in each:
            diffuseMap = each

cm.setAttr(rsMat+".refl_brdf",1)
cm.setAttr(rsMat+".refl_fresnel_mode",2)


cm.connectAttr(diffuseMap+".outColor",rsMat+".diffuse_color")
cm.connectAttr(roughMap+".outAlpha",rsMat+".refl_roughness")
cm.connectAttr(metalMap+".outColor",rsMat+".refl_metalness")



cm.connectAttr(diffuseMap+".outColor",rsMat+".diffuse_color")
