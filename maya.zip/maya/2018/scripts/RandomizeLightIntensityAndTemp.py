import maya.cmds as cm
import random

shopLightsGrps = cm.ls(sl=True)

for eachLightGrp in shopLightsGrps:
    lights = cm.listRelatives(eachLightGrp,children=True)
    for eachLight in lights:
        currTemp = cm.getAttr(eachLight+".temperature")
        randTemp = random.randrange(-400, 400, 100)
        cm.setAttr(eachLight+".temperature",currTemp+randTemp)
        
        intensityAttr = ".intensity"
        if "multiplier" in cm.listAttr(eachLight):
            intensityAttr = ".multiplier"
            
        
        currIntensity = cm.getAttr(eachLight+intensityAttr)
        randIntensity = random.randrange(-200, 200, 100)
        cm.setAttr(eachLight+intensityAttr,currIntensity+randIntensity)