#project name: Flame Force Tunnel Sequence
#prepare environment for building assets
import maya.cmds as cm


def main():
    #switch renderer------------
    cm.setAttr("defaultRenderGlobals.currentRenderer", "redshift", type="string")

    #image size --------------

    cm.setAttr("defaultResolution.width", 1920)
    cm.setAttr("defaultResolution.height", 1080)
    cm.setAttr("defaultResolution.deviceAspectRatio", 1.777)
    cm.setAttr("defaultResolution.pixelAspect", 1)
    cm.setAttr("defaultRenderGlobals.enableDefaultLight",0)
    cm.setAttr("redshiftOptions.motionBlurEnable",1)

    #change camera clip plane settings-----------
    cm.setAttr("perspShape.nearClipPlane",10)
    cm.setAttr("perspShape.farClipPlane",100000)

    #create dome light-------------
    #light = mel.eval("redshiftCreateDomeLight")
    domeLight = cm.shadingNode("RedshiftDomeLight",asLight=True)
    domeMapPath = "G:\\ShawnRoot\\Resources\\CG\\HDRI\\HDRI_haven\\potsdamer_platz_4k.hdr"
    cm.setAttr(domeLight+".tex0",domeMapPath,type="string")

    domeLight2 = cm.shadingNode("RedshiftDomeLight",asLight=True)
    domeMapPath2 = "G:\\ShawnRoot\\Resources\\CG\\HDRI\\HDRI_haven\\museumplein_4k.hdr"
    cm.setAttr(domeLight2+".tex0",domeMapPath2,type="string")
    cm.setAttr(domeLight2+".exposure0",-2)

    domeLight3 = cm.shadingNode("RedshiftDomeLight",asLight=True)
    domeMapPath3 = "G:\\ShawnRoot\\Resources\\CG\\HDRI\\Peter Guthrie SKY HDRi Collection\\2003 Dusk Blue\\2003 Dusk Blue.hdr"
    cm.setAttr(domeLight3+".tex0",domeMapPath3,type="string")
    cm.setAttr(domeLight3+".exposure0",-5)

if __name__ == "__main__":
    main()
