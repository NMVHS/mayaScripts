import maya.cmds as cm

sel = cm.ls(sl=True)

for each in sel:
    assetName = each.split("_v")[0]
    toReplaceObj = assetName + ":" + assetName
    
    print toReplaceObj
    
    children = cm.listRelatives(each,children=True,shapes=False)
    
    for eachChild in children:
        if "Shape" not in eachChild:
            cm.delete(eachChild)
    
    cm.parent(toReplaceObj,each)
    
    
    cm.xform(toReplaceObj,t=[0,0,0])
    cm.xform(toReplaceObj,ro=[0,0,0])