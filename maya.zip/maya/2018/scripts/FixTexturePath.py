#Relink the textures
import maya.cmds as cm

selection = cm.ls(sl=True) #Textures in HyperShade

for eachSel in selection:
    imagePath =  cm.getAttr(eachSel + ".fileTextureName")
    keyword = "Maps_Export/"
    splitPath = imagePath.split(keyword)
    splitPath.insert(1,keyword + "2K/")
    newPath = "".join(splitPath)
    print newPath
    cm.setAttr(eachSel + ".fileTextureName",newPath, type = "string")