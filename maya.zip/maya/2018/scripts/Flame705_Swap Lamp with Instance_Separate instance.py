#Setting up street lamps in the FlameForce City Scene
#Select the instance source

import maya.cmds as cm

def main():
    selection = cm.ls(selection = True)
    sourceShapes = cm.listRelatives(selection, ad=True, type = "mesh", path = True) #get all the shapes under the selected lamp
    
    meshLightList = [] #these are all shapes
    #Remove the light itself
    for singleSource in reversed(sourceShapes):
        if "Emissive" in singleSource:
            meshLightList.append(singleSource)
            sourceShapes.remove(singleSource)
    
    sourceParent = cm.listRelatives(selection, parent = True)
    lampList = cm.listRelatives(sourceParent,children = True) #get all other lamp nodes
    lampList.remove(selection[0]) #remove the orginal selection
    
    for eachLamp in lampList:
        eachLampShapes = cm.listRelatives(eachLamp, ad=True, type = "mesh", path = True) #get each lamp's meshes
        
        #Remove the light itself
        for singleMesh in reversed(eachLampShapes):
            if "Emissive" in singleMesh:
                meshLightList.append(singleMesh)
                eachLampShapes.remove(singleMesh)
        
        cnt = 0
        for eachMesh in eachLampShapes:
            print eachMesh
            eachMeshParent = cm.listRelatives(eachMesh, parent = True) #Get parent transform node
            print eachMeshParent
            meshInstance = cm.parent(sourceShapes[cnt],eachMeshParent,add= True, shape = True)
            cm.delete(eachMesh)
            cnt = cnt + 1
    
    #convert the meshLightList(shapes) to transform node
    meshToSelect = []
    for eachShape in meshLightList:
        meshXform = cm.listRelatives(eachShape,parent = True)
        meshToSelect.append(meshXform[0])
    
    cm.select(meshToSelect)


if __name__ == '__main__':
    main()