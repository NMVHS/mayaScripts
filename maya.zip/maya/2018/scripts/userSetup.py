# run Create 3d Characters startup

import maya.mel as mel

print "executing custom userSetup.py"
mel.eval('if( startsWith( `whatIs DeadlineMayaClient`, "Mel procedure found in" ) ){ DeadlineMayaClient(); }else{ warning( "DeadlineMayaClient either has errors or has not been installed." ); }')
print "DeadlineClient loaded"
print "__INPUT__NOW__"

import create3dcharacters
