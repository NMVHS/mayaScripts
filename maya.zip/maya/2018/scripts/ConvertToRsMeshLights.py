#Create new RsPhysicalLights for each selection
#Snap RsLight to the mesh and link automatically
#Select the mesh to snapped to then select the RsLight
import maya.cmds as cm

def main():
    #Get the selection in the scene, String here!
    selection = cm.ls(selection = True) #Both are transform nodes

    for eachSel in selection:
        cm.hide(eachSel)
        meshNode = eachSel #meshTransform node

        #Create a new RSPhysicalLight
        newRsLight = cm.shadingNode("RedshiftPhysicalLight",asLight = True)#The transform node of the rsLight
        rsLightShape = cm.listRelatives(newRsLight)[0] #The shape node of the new rsLight


        #if the selection has a parent, put light under that parent
        eachSelParent = cm.listRelatives(eachSel, parent = True)
        if eachSelParent != None:
            cm.parent(newRsLight,eachSelParent[0])

        #copy the transformation info of the mesh to the light
        cm.copyAttr(meshNode,newRsLight,attribute = ["translate","rotate","scale"], values = True)

        #Change the light area shape to "Mesh"
        cm.setAttr(rsLightShape + ".areaShape", 4)

        #Normally what is selected if the transform node, but we need to get the actual geometry of the mesh
        if cm.objectType(meshNode,isAType = "transform"):
            meshes = cm.listRelatives(eachSel, noIntermediate = True, shapes = True, path = True, type = "mesh")
            if len(meshes) > 0:
                meshNode = meshes[0]


        #Make sure the meshNode is "mesh" type
        if cm.objectType(meshNode, isAType = "mesh"):
            #Link the mesh and the light-----------------------
            meshInstance = cm.parent(meshNode, newRsLight, addObject = True, shape = True)#Create a instance under parent

            #meshNode = meshInstance[0]
            #connect the nodes
            cm.connectAttr(meshInstance[0] + ".message", rsLightShape + ".areaShapeObject")


if __name__ == '__main__':
    main()
