#Replace Cloned object with instance
import maya.cmds as cm

def main():
    selection = cm.ls(selection = True) #Select the lamp object
    
    if len(selection) != 1: return
    
    children = cm.listRelatives(selection)
    
    for eachObj in children:
        if "Emissive" in eachObj:
            lampLight = eachObj
        else:
            lampBody = eachObj
    
    #Get the parent object
    parentNode = cm.listRelatives(selection, parent = True)
    allLamps = cm.listRelatives(parentNode, children = True)
    
    allLamps.remove(selection[0])
    allEmissiveLight = [lampLight]
    
    for eachLamp in allLamps:
        
        #delete that duplicated lamp body
        eachLampChildren = cm.listRelatives(eachLamp, children = True)
        for eachLampChild in eachLampChildren:
            if "Emissive" not in eachLampChild:
                toReplace = eachLampChild
            else:
                eachLight = eachLampChild
                
        lampBodyInstance = cm.instance(lampBody)
        newLampBody = cm.parent(lampBodyInstance, eachLamp)
        cm.copyAttr(toReplace,newLampBody,attribute = ["translate","rotate","scale"],values = True)
        
        cm.delete(toReplace) #Delete the original duplicate of the light body
        allEmissiveLight.append(eachLight)
        
    cm.select(allEmissiveLight)
        
    

if __name__ == '__main__':
    main()