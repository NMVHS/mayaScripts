Personal toolsets developed while working.
