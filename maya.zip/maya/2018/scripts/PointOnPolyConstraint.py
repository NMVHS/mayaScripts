import maya.cmds as cm

sel = cm.ls(sl=True,flatten=True)

baseName = "SHPDgirl_eyelashes"

cnt = 0
for eachVtx in sel:
    #create a empty group
    rivetGrp = cm.group(name=baseName + "_rivet_"+str(cnt),empty=True,world=True)
    
    #create a locator
    rivetLoc = cm.spaceLocator(name=baseName+"_rivet_loc_"+str(cnt))
    
    #create a joint
    rivetJnt = cm.joint(name=baseName+"_rivet_jnt_"+str(cnt))
    
    #cm.parent(rivetJnt,rivetLoc)
    cm.parent(rivetLoc,rivetGrp)
    cm.select(clear=True)
    cm.select(eachVtx,rivetLoc)
    
    cm.pointOnPolyConstraint(eachVtx,rivetLoc,maintainOffset=False)
    
    cnt += 1