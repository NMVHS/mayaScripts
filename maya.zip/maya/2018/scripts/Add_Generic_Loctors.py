import maya.cmds as cm

sel = cm.ls(sl=True)

for each in sel:
    eachPos = cm.xform(each,q=True,ws=True,t=True)
    
    offsetGrp = cm.listRelatives(each,parent=True)
    
    newGrp = cm.group(empty=True,world=True,name=each+"_loc_grp")
    cm.xform(newGrp,ws=True,t=eachPos)
    
    newLoc = cm.spaceLocator(name=each+"_loc")
    cm.xform(newLoc,ws=True,t=eachPos)
    cm.parent(newLoc,newGrp)
    
    cm.parentConstraint(newLoc,offsetGrp,maintainOffset=True)