#Replace copy with instance

import maya.cmds as cm

selection = cm.ls(selection = True)

print selection

sourceObj = selection[0]
selection.pop(0)
shapeSource = cm.listRelatives(sourceObj)

for eachCopy in selection:
    meshNode = cm.listRelatives(eachCopy) #get the Shape of each object
    print meshNode
    cm.parent(shapeSource,eachCopy,add=True, shape= True)
    cm.delete(meshNode)