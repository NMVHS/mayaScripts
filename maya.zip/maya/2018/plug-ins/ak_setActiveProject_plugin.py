"""
ak_setActiveProject_plugin.py
Alex Kline | dev[at]alexkline<dot>com
2017-08-28
http://blog.alexkline.com/2017/08/28/maya-set-project/

This Maya plugin will set the active project before opening and saving scenes, just like Softimage.  You can additionally call the command aksap() from maya cmds.
Plugin Template from Chad Vernon's site:  http://www.chadvernon.com/blog/resources/maya-api-programming/your-first-plug-in/
"""

import maya.cmds as cmds
import maya.OpenMaya as api
import maya.OpenMayaMPx as OpenMayaMPx
import os

cusCall_beforeOpen, cusCall_beforeSave = None, None


class AK_SetActiveProject(OpenMayaMPx.MPxCommand):
    def __init__(self):

        OpenMayaMPx.MPxCommand.__init__(self)

    def doIt(self, type="", *argv):
        """set the active project based on file location"""

        #check what type of callback issued command
        if type == "load":
            scnPath = api.MFileIO.beforeOpenFilename()
        elif type == "save":
            scnPath = api.MFileIO.beforeSaveFilename()
        else:
            scnPath = cmds.file(loc=True, q=True)

        #convert scene path to list
        path, file = os.path.split(scnPath)
        scnPathList = []
        while True:
            #this while loop breaks folders into list.  Only works for absolute list...
            #https://stackoverflow.com/questions/3167154/how-to-split-a-dos-path-into-its-components-in-python
            path, folder = os.path.split(path)

            if folder != "":
                scnPathList.append(folder)
            else:
                if path != "":
                    scnPathList.append(path)

                break

        scnPathList.reverse()

        #grabbing current, active-project
        curProj = cmds.workspace(q=True, rd=True)

        #looping back from scene file
        for d in range(1, len(scnPathList)):

            #assemble path based on location of d in scnPathList
            dirPath = os.path.join(*scnPathList[0:int(len(scnPathList) - d)])

            #checking for workspace file
            if os.path.isfile(os.path.join(dirPath, 'workspace.mel')):

                #compare the dirPath with the current project location
                #using os.path.normpath to make sure slashes are all the same
                if os.path.normpath(dirPath) == os.path.normpath(curProj):

                    #dirPath matches the current project location
                    print 'ak_setActiveProject | same project detected.  Not updating project...'
                    break

                else:

                    #set dirPath as the current workspace
                    cmds.workspace(dirPath, openWorkspace=True)

                    #save workspace to local prefs
                    cmds.workspace(saveWorkspace=True)

                    print 'ak_setActiveProject | set project -- %s' % (str(dirPath))
                    break

        else:
            #check if scene is saved
            if cmds.file(sn=True, q=True) == '':
                cmds.confirmDialog(title="ak_setActiveProject Error",
                                message="Scene not saved.  Please open or save this file before running the aksap command.")
            else:
                cmds.confirmDialog(title="ak_setActiveProject Error",
                                message="Unable to change workspace as there is no workspace.mel found in the directories to this scene.")

def creator():
    return OpenMayaMPx.asMPxPtr( AK_SetActiveProject() )

def initializePlugin(obj):
    global cusCall_beforeLoad
    global cusCall_beforeSave
    plugin = OpenMayaMPx.MFnPlugin(obj, 'Alex Kline', '1.0', 'Any')

    try:
        plugin.registerCommand('aksap', creator)
        sap = AK_SetActiveProject()
        cusCall_beforeLoad = api.MSceneMessage.addCallback(api.MSceneMessage.kBeforeOpen, sap.doIt, "load")
        cusCall_beforeSave = api.MSceneMessage.addCallback(api.MSceneMessage.kBeforeSave, sap.doIt, "save")
    except:
        raise RuntimeError, 'Failed to register command'

def uninitializePlugin(obj):
    global cusCall_beforeLoad
    global cusCall_beforeSave
    plugin = OpenMayaMPx.MFnPlugin(obj)

    try:
        plugin.deregisterCommand('aksap')
        api.MSceneMessage.removeCallback(cusCall_beforeLoad)
        api.MSceneMessage.removeCallback(cusCall_beforeSave)
    except:
        raise RuntimeError, 'Failed to unregister command'
