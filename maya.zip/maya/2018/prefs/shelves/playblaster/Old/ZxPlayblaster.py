import maya.cmds as cm
import os

def main():
    ZxPlayblastTool = ZxPlayblast()

class ZxPlayblast:
    """
    1. automating play blast saving path
    """
    def __init__(self):
        uiWindow = "ZxPlayblast"

        if cm.window(uiWindow,exists=True):
            cm.deleteUI(uiWindow,window=True)

        startTime,endTime = self.getTimelineRange()
        win = cm.window(uiWindow,width = 200,height = 10, title = "ZxPlayblast")
        baseLayout = cm.rowLayout(numberOfColumns=3)
        frameRangeLayout = cm.columnLayout(rowSpacing=5,parent=baseLayout)
        row1 = cm.rowLayout(numberOfColumns=2,parent=frameRangeLayout)
        cm.text(label="From: ",width=30,align="left")
        cm.timeField("startFrame",width=50,value=startTime)
        row2 = cm.rowLayout(numberOfColumns=2,parent=frameRangeLayout)
        cm.text(label="To: ",width=30,align="left")
        cm.timeField("endFrame",width=50,value=endTime)

        cm.button("blastRange",label="PLAYBLAST\nRange",bgc=[0.6,0.8,0.2],parent =baseLayout, width=70,height=50,command=lambda x:self.playblast("range"))
        cm.button("blastWorkingArea",label="PLAYBLAST\nWorking\nArea",bgc=[0.2,0.8,0.2],parent=baseLayout,width=70,height=50,command=lambda x:self.playblast("working"))
        cm.showWindow(win)

        self.getTimelineRange()

    def getTimelineRange(self,*args):
        startTime = cm.playbackOptions(minTime=True,q=True)
        endTime = cm.playbackOptions(maxTime=True,q=True)
        return startTime,endTime

    def playblast(self,option,*args):
        if option == "working":
            renderStartTime,renderEndTime = self.getTimelineRange()
        else:
            renderStartTime = cm.timeField("startFrame",value=True,q=True)
            renderEndTime = cm.timeField("endFrame",value=True,q=True)

        projectPath = self.getProjectPath()
        sceneName = self.getSceneName()
        savingPath = projectPath + "\\playblasts\\"  + sceneName +"\\" + sceneName

        renderWidth = cm.getAttr("defaultResolution.width")
        renderHeight = cm.getAttr("defaultResolution.height")

        if renderEndTime < renderStartTime:
            renderEndTime = renderStartTime

        cm.playblast(format="image", filename=savingPath,sequenceTime=False,
                    clearCache=False,viewer=True,showOrnaments=True,
                    startTime=renderStartTime,endTime=renderEndTime,
                    framePadding=4,percent=100,compression="jpg",quality=70,width=renderWidth,height=renderHeight)

    def getProjectPath(self):
        projectPath = cm.workspace(q=True,rootDirectory=True)
        return projectPath

    def getSceneName(self):
        sceneName = cm.file(q=True,sceneName=True,shortName=True)
        sceneName = os.path.splitext(sceneName)[0]
        return sceneName
